###################################################
### chunk number 1: load
###################################################
#line 162 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw"
library(forensim)


###################################################
### chunk number 2: LR
###################################################
#line 167 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw"
victim <- "15/18"
suspect <- "14/17"


###################################################
### chunk number 3: LR1
###################################################
#line 185 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw"
LR(stain = c(14, 15, 17, 18), freq = c(0.033, 0.331, 0.239, 0.056), xp = 0, Tp = c(victim, suspect), Vp = NULL, Td = NULL, 
Vd = c(victim, suspect), xd = 2,theta=0)


###################################################
### chunk number 4: LR2
###################################################
#line 199 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw"
LR(stain = c(14, 15, 17, 18), freq = c(0.033, 0.331, 0.239, 0.056), 
xp = 0, Tp = c(victim, suspect), Vp = NULL, Td = victim, Vd = suspect, xd = 1,theta=0)


###################################################
### chunk number 5: LR
###################################################
#line 330 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw"
LR(stain=c(14,15,17,18),freq=c(0.033,0.331,0.239,0.056),xp=0,Tp=c(victim,suspect),Vp=NULL,Td=victim,Vd=suspect,xd=1,theta=0.03)


###################################################
### chunk number 6: theta correction
###################################################
#line 336 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw"
theta<-seq(0,0.03,by=0.001)
theta


###################################################
### chunk number 7: sapply
###################################################
#line 345 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw"
sapply(theta, function(i) LR(stain=c(14,15,17,18),freq=c(0.033,0.331,0.239,0.056),xp=0,Tp=c(victim,suspect),Vp=NULL,Td=victim,
Vd=suspect,xd=1,theta=i))


###################################################
### chunk number 8: save LR
###################################################
#line 352 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw"
LRtheta<-sapply(theta, function(i) LR(stain=c(14,15,17,18),freq=c(0.033,0.331,0.239,0.056),xp=0,Tp=c(victim,suspect),
Vp=NULL,Td=victim,Vd=suspect,xd=1,theta=i))


###################################################
### chunk number 9: plotLR
###################################################
#line 359 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw"
plot(theta,LRtheta)


###################################################
### chunk number 10: load
###################################################
#line 380 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw"
1/(24*0.033*0.331*0.239*0.056)


###################################################
### chunk number 11: load
###################################################
#line 392 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw"
1/(2*0.033*0.239)


###################################################
### chunk number 12: load
###################################################
#line 411 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw"
(1+3*0.03)*(1+4*0.03)/(2*(0.03+(1-0.03)*0.033)*(0.03+(1-0.03)*0.239))


###################################################
### chunk number 13: LR2
###################################################
#line 415 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw"
LR(stain=c(14,15,17,18),freq=c(0.033,0.331,0.239,0.056),xp=0,Tp=c(victim,suspect),Vp=NULL,Td=victim,Vd=suspect,xd=1,theta=0.03)


###################################################
### chunk number 14: stains
###################################################
#line 423 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw"
stainD3<-c(15,16,17)
stainv<-c(15,16,18)
stainFGA<-c(20,21,22,24,26)


###################################################
### chunk number 15: suspects
###################################################
#line 430 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw"
suspectD3<-"15/17"
suspectv<-"16/18"
suspectFGA<-"20/26"


###################################################
### chunk number 16: LR
###################################################
#line 438 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw"
LRD3<-LR(stain=stainD3,freq=rep(0.1,3),xp=2,Tp=c(suspectD3),Vp=NULL,Td=NULL,Vd=suspectD3,xd=3,theta=0)
LRD3


###################################################
### chunk number 17: LR2
###################################################
#line 442 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw"
LRDv<-LR(stain=stainv,freq=rep(0.1,3),xp=2,Tp=c(suspectv),Vp=NULL,Td=NULL,Vd=suspectv,xd=3,theta=0)
LRDv


###################################################
### chunk number 18: LR3
###################################################
#line 446 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw"
LRDFGA<-LR(stain=stainFGA,freq=rep(0.1,5),xp=2,Tp=c(suspectFGA),Vp=NULL,Td=NULL,Vd=suspectFGA,xd=3,theta=0)
LRDFGA


###################################################
### chunk number 19: prodLR
###################################################
#line 451 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw"
LRD3*LRDv*LRDFGA


###################################################
### chunk number 20: ABdef
###################################################
#line 464 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw"
D <- 0.01
pA <- 0.2
pB <- 0.1


###################################################
### chunk number 21: load
###################################################
#line 471 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw"
1/(2*pA*pB) 


###################################################
### chunk number 22: LR
###################################################
#line 475 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw"
LR(stain=c("A","B"),freq=c(0.2,0.1),xp=0,Tp="A/B",Vp=NULL,Td=NULL,Vd="A/B",xd=1,theta=0)


###################################################
### chunk number 23: LR
###################################################
#line 480 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw"
LR(stain=c("A"),freq=c(0.2),xp=0,Tp="A/A",Vp=NULL,Td=NULL,Vd="A/A",xd=1,theta=0)


###################################################
### chunk number 24: LR
###################################################
#line 484 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw"
25^9


###################################################
### chunk number 25: load
###################################################
#line 490 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw"
D/((1+D)*pA^2+2*pA*(1-pA)*D)


###################################################
### chunk number 26: load
###################################################
#line 495 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw"
25^9*0.2293578


###################################################
### chunk number 27: xydef eval=FALSE
###################################################
## #line 500 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw"
## D=seq(0,1,length=1000)
## pA=0.2
## LR1=D/((1+D)*pA^2+D*2*pA*(1-pA))


###################################################
### chunk number 28: 
###################################################
#line 509 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw"
#line 500 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw#from line#509#"
D=seq(0,1,length=1000)
pA=0.2
LR1=D/((1+D)*pA^2+D*2*pA*(1-pA))
#line 510 "C:/DOCUME~1/Dibule/Bureau/MAJFOR~1/forensimCompi/forensim/inst/doc/LR_vignette.Rnw"
plot(D,LR1,type="l",xlab="Drop out probability",ylab="LR1")
title("Stain:A.Suspect:AB.pA=0.2.\n LR as a function of drop out probability")


