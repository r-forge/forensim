
.First.lib <-function (lib, pkg) {
library.dynam("forensim", pkg, lib)
 cat("   ### forensim 1.1.2 is loaded ### \n")

}
