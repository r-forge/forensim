
.First.lib <-function (lib, pkg) {

 cat("   ### forensim 1.1.0 is loaded ### \n")
library.dynam("forensim", pkg, lib)
}
