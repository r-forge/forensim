### Name: A2.simu
### Title: A Tcl/Tk graphical user interface for simple DNA mixtures
###   resolution using allele peak heights or areas information when two
###   alleles are observed at a given locus
### Aliases: A2.simu
### Keywords: htest

### ** Examples

A2.simu()



