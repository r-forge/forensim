### Name: A4.simu
### Title: A Tcl/Tk graphical user interface for simple DNA mixtures
###   resolution using allele peak heights or areas when four alleles are
###   observed at a given locus
### Aliases: A4.simu
### Keywords: htest

### ** Examples

A4.simu()



