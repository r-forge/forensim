### Encoding: UTF-8

### Name: Accessors
### Title: Accessors for forensim objects
### Aliases: $,simugeno-method $,simumix-method $,tabfreq-method
###   $<-,simugeno-method $<-,simumix-method $<-,tabfreq-method
### Keywords: manip

### ** Examples

data(strusa)
class(strusa)

strusa@pop.names
#equivalent 
strusa$pop.names



