### Encoding: UTF-8

### Name: Cmn
### Title: The number of all possible combinations of m elements among n
###   with repetitions
### Aliases: Cmn
### Keywords: models

### ** Examples

Cmn(2,3)
comb(2,3)



