### Name: changepop
### Title: Function to change population-related information in forensim
###   objects
### Aliases: changepop
### Keywords: manip

### ** Examples

data(strveneto)
tab1 <- simugeno(strveneto,n=100)
tab2 <- changepop(tab1,"Veneto","VENE")
tab1$pop.names
tab2$pop.names



