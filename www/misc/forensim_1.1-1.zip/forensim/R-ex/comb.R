### Encoding: UTF-8

### Name: comb
### Title: Generate all possible combinations of m elements among n with
###   repetitions
### Aliases: comb
### Keywords: models

### ** Examples

#combine 2 objcets among 3 with repetitions
Cmn(2,3)
comb(2,3)



