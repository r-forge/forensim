### Encoding: UTF-8

### Name: simumix constructor
### Title: simumix constructor
### Aliases: simumix-methods simumix as.simumix is.simumix
### Keywords: manip datagen

### ** Examples

data(Tu)
tab<-simugeno(tabfreq(Tu),n=1200)
#simulation of a 3-person mixture characterized with markers FGA, TH01 and TPOX 
simumix(tab,which.loc=c('FGA','TH01', 'TPOX') , n =3)




