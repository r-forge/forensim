### Encoding: UTF-8

### Name: tabfreq constructor
### Title: tabfreq constructor
### Aliases: tabfreq-methods tabfreq as.tabfreq is.tabfreq
### Keywords: manip datagen

### ** Examples

data(Tu)
tabfreq(Tu,pop.names=factor("Tu"))




