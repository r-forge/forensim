### Encoding: UTF-8

### Name: simugeno constructor
### Title: simugeno constructor
### Aliases: simugeno-methods simugeno as.simugeno is.simugeno
### Keywords: manip datagen

### ** Examples

data(Tu)
tab<-tabfreq(Tu)
#simulation of 3 individual genotypes for the STR  marker FGA
geno1 <- simugeno(tab,which.loc='FGA', n =1000)
geno1@tab.geno



