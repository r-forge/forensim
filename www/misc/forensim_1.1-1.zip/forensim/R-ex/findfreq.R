### Encoding: UTF-8

### Name: findfreq
### Title: Finds the allele frequencies of a mixture from a tabfreq object
### Aliases: findfreq
### Keywords: misc

### ** Examples

data(strusa)
s2<-simumix(simugeno(strusa,n=c(0,2000,0)),ncontri=c(0,2,0))
findfreq(s2,strusa,refpop="Cauc")



