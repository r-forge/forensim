### Encoding: UTF-8

### Name: dataL
### Title: Generic formula of the likelihood of the observed alleles in a
###   mixture conditional on the number of contributors for a specific
###   locus
### Aliases: dataL
### Keywords: htest

### ** Examples

#likelihood of observing two alleles at frequencies 0.1 and 0.01 when the number of 
#contributors is 2, in two cases:  theta=0 and theta=0.03
dataL(x=2,p=c(0.1,0.01), theta=0)
dataL(x=2,p=c(0.1,0.01), theta=0.03)



