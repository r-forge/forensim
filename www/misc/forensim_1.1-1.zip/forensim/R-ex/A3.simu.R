### Name: A3.simu
### Title: A Tcl/Tk graphical user interface for simple DNA mixtures
###   resolution using allele peak heights or areas when three alleles are
###   observed at a given locus
### Aliases: A3.simu
### Keywords: htest

### ** Examples

A3.simu()



